# fichaje
Proyecto muy muy sencillo para crear un sistema de fichaje de las entradas y salidas de los trabajadores de una empresa. Se usa JavaFX + JDBC + MySQL

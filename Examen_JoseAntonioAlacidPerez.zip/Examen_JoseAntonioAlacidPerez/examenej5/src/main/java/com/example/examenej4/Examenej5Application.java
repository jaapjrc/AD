package com.example.examenej4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examenej5Application {

	public static void main(String[] args) {
		SpringApplication.run(Examenej5Application.class, args);
	}

}

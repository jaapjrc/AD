package com.example.examenej4.modelo;

public enum TipoProducto {
    CAMARA,FOCO,MICROFONO
}
